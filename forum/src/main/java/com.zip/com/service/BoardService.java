package com.service;

import com.entity.BoardVO;
import com.repository.BoardRepository;
import lombok.RequiredArgsConstructor;

import java.util.List;

import org.springframework.stereotype.Service;

@Service
@RequiredArgsConstructor
public class BoardService {

    private final BoardRepository boardRepository;

    public List<BoardVO> getCommonList() throws Exception {
        return boardRepository.listCommon();
    }

    public List<BoardVO> getBestList(int likeCut, int clickCut) throws Exception {
        return boardRepository.listBest(likeCut, clickCut);
    }

    public List<BoardVO> getUserList(String regCode) throws Exception {
        return boardRepository.listUser(regCode);
    }
}