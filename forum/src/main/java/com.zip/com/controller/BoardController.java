package com.controller;

import com.dto.*;
import com.entity.BoardVO;
import com.security.LoginVO;
import com.service.BoardService;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpSession;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

@RestController
@RequestMapping("/board")
public class BoardController {
	@Autowired BoardService boardService;

	@RequestMapping(value = "/list", method = RequestMethod.POST)
	public List<BoardVO> list(@RequestParam Map<String, String> params) throws Exception {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session = request.getSession(false);
		LoginVO loginVO = session == null ? null : (LoginVO) session.getAttribute("loginVO");
		String mode = params.get("mode");
		List<BoardVO> result = new ArrayList<>();
		
		switch(mode) {
			case "best":
				// 특별한 설정이 없으면 좋아요 수 10개, 조회수 100회
				int likeCut  = Integer.parseInt(params.getOrDefault("likeCut", "10"));
				int clickCut = Integer.parseInt(params.getOrDefault("clickCut", "100"));
				result = boardService.getBestList(likeCut, clickCut);
				break;

			case "my": 
				String regCode = loginVO.getCode();
				result = boardService.getUserList(regCode);
				break;

			default:
				result = boardService.getCommonList();
				break;
		}

		return result;
	}

	@RequestMapping(value = "/write", method = RequestMethod.POST)
	public Map<String, String> write(@RequestParam Map<String, String> params) throws Exception {
		HttpServletRequest request = ((ServletRequestAttributes) RequestContextHolder.getRequestAttributes()).getRequest();
		HttpSession session = request.getSession(false);
		LoginVO loginVO = session == null ? null : (LoginVO) session.getAttribute("loginVO");
		params.put("regCode", loginVO.getCode());
		params.put("regNickname", loginVO.getNickname());

		String regIpAddress = request.getRemoteAddr();
		params.put("regIpAddress", regIpAddress);

		LocalDateTime now = LocalDateTime.now();
		DateTimeFormatter dateFormatter = DateTimeFormatter.ofPattern("yyyyMMdd");
		DateTimeFormatter timeFormatter = DateTimeFormatter.ofPattern("HHmmss");

		String regDate = now.format(dateFormatter);
		String regTime = now.format(timeFormatter);

		params.put("regDate", regDate);
		params.put("regTime", regTime);
		
		/*이제 여기에 코드 넣어줘*/

		return new HashMap<>();
	}
}